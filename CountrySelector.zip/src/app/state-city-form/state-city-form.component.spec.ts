import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StateCityFormComponent } from './state-city-form.component';

describe('StateCityFormComponent', () => {
  let component: StateCityFormComponent;
  let fixture: ComponentFixture<StateCityFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StateCityFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateCityFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
