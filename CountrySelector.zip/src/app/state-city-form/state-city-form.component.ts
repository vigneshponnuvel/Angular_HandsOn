import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-state-city-form',
  templateUrl: './state-city-form.component.html',
  styleUrls: ['./state-city-form.component.css']
})
export class StateCityFormComponent implements OnInit {

  countries = ['NA', 'India', 'US', 'UK'];
  states;
  countryValue = '';
  stateValue = '';
  showStates = false;

  @Output() sharedValue = new EventEmitter();

  selectedCountry($event){
    this.countryValue = $event.target.value;
    this.showStates = true;
    switch(this.countryValue){
      case 'India':
          this.states = ['NA', 'Tamil Nadu', 'Andhra', 'West Bengal', 'Kerala'];
          break;
      case 'US':
          this.states = ['NA', 'Florida', 'Texas', 'Arizona', 'New York'];
          break;
      case 'UK':
          this.states = ['NA', 'England', 'Scotland', 'Wales', 'Ireland'];
          break;
      default:
          this.states = [];
          this.showStates = false; 
          this.sharedValue.emit('');
    }
  }

  selectedState($event){
    this.stateValue = $event.target.value;
    this.sharedValue.emit('Selected Country: ' + this.countryValue + ' and Selected State: ' + this.stateValue);
  }

  constructor() { }

  ngOnInit() {
  }

}
