import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-greet',
  templateUrl: './greet.component.html',
  styleUrls: ['./greet.component.css']
})
export class GreetComponent implements OnInit {

  status=true;
  title='Test title value';
  pathLoc = 'http://www.google.com';
  cities=["Chennai","Delhi","Kolkata"];
  
 changeStatus(){
   this.status = !this.status;
 }

  constructor() { }

  ngOnInit() {
  }

}
